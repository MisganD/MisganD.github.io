function [LL] = Normal_generalized_exponential(par,y,X)
lam=par(1);
s=par(2);
if lam<=0
    lik=-100000;
elseif s<=0
    lik=-100000;
else
coef=par(3:end);
e=y-X*coef';
mu1=(e-s^2*lam);
mu2=(e-s^2*lam*2);
lik=log(lam)+log(2)-e*lam+.5*s^2*lam^2+log(normcdf(mu1/s)-...
    exp(-e*lam+s^2*lam^2+.5*s^2*lam^2).*normcdf(mu2/s)); 
end
LL=-sum(lik);
end