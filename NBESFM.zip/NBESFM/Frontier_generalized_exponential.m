function [MLE, standerr, LL, Efficiency] = Frontier_generalized_exponential(y,X)
init = [1,1,0,0,0,0,0];
[MLE,fval,~,~,~,hessian]=fminunc(@(par)Normal_generalized_exponential(par,y,X),init);
standerr=sqrt(diag(inv(hessian)));
LL = -fval;
lambda=MLE(1);s=MLE(2);
res=y-X*MLE(3:end)';
mu1=-(res+lambda*s^2);
mu2=-(res+2*lambda*s^2);
k=res*lambda+.5*s^2*lambda^2*3;
C=(normcdf(mu1/s)-normcdf(mu2/s).*k);
w1=normcdf(mu1/s)./C;w2=normcdf(mu2/s)./C;
Eff_m1=w1.*(mu1+s*normpdf(mu1/s)./normcdf(mu1/s));
Eff_m2=w2.*(mu2+s*normpdf(mu2/s)./normcdf(mu2/s));
Eff_mean=Eff_m1-Eff_m2;
Efficiency=exp(-Eff_mean);
MLE = MLE';
end