function Est = asymmean_weighted(MLE)
al = 1/MLE(1);
lam = MLE(1)*MLE(2);
Est = [al;lam;MLE(3:end)];
end