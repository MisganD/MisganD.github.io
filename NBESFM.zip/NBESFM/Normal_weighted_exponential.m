function [LL] = Normal_weighted_exponential(par,y,X)
a=par(1);
lam=par(2);
s=par(3);
if a<=0
    lik=-100000;
elseif lam<=0
    lik=-100000;
elseif s<=0
    lik=-100000;
else
coef=par(4:end);
e=y-X*coef';
mu1=(e-s^2*lam);
mu2=(e-s^2*lam*(1+a));
lik=log(lam)+log(a+1)-log(a)-e*lam+.5*s^2*lam^2+log(normcdf(mu1/s)-...
    exp(-e*lam*a+s^2*lam^2*a+.5*s^2*lam^2*a^2).*normcdf(mu2/s)); 
end
LL=-sum(lik);
end