function [draw] = tnor(mu,s2,simu)
rng(123)
h=haltonset(1);
halton=net(h,simu);
halton( halton <= 0 ) = 0.0001;
U=halton;
s=sqrt(s2);
k=-mu./s;
p=normcdf(-k);
l=normcdf(k);
q=length(U);
draw=repmat(mu,q,1)+s*norminv(repmat(l,q,1)+U*p);  
end
