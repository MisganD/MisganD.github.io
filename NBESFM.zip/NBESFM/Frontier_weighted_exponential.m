function [MLE, standerr, LL, Efficiency, hessian] = Frontier_weighted_exponential(y,X)
init = [1,1,1,0,0,0,0,0];
[MLE,fval,~,~,~,hessian]=fminunc(@(par)Normal_weighted_exponential(par,y,X),init);
standerr=abs(sqrt(diag(inv(hessian))));
LL = -fval;
a=MLE(1);l=MLE(2);s=MLE(3);
res=y-X*MLE(4:end)';
mu1=-(res+l*s^2);
mu2=-(res+(a+1)*l*s^2);
k=res*l*a+.5*s^2*l^2*(a^2+2*a);
C=(normcdf(mu1/s)-normcdf(mu2/s).*k);
w1=normcdf(mu1/s)./C;w2=normcdf(mu2/s)./C;
Eff_m1=w1.*(mu1+s*normpdf(mu1/s)./normcdf(mu1/s));
Eff_m2=w2.*(mu2+s*normpdf(mu2/s)./normcdf(mu2/s));
Eff_mean=Eff_m1-Eff_m2;
Efficiency=exp(-Eff_mean);
MLE = MLE';
end