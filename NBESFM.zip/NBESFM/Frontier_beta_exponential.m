function [MLE, Standerr, p_value, LL, Efficiency] = Frontier_beta_exponential(y,X,simu,lb,ub)
theta0 = [1,1,1,1,0,0,0,0,0];       % this sets the initial parameter vector
%lb = [0,0,0,0,-Inf,-Inf,-Inf,-Inf,-Inf];
%ub = [Inf,Inf,Inf,Inf,Inf,Inf,Inf,Inf,Inf];
[MLE,fval,~,~,~,~,hessian] = fmincon(@(par) Normal_beta_exponential(par,y,X,simu),theta0,[],[],[],[],lb,ub);
Standerr = sqrt(diag(inv(hessian)));
t_static=MLE'./Standerr;
df=length(y)-length(MLE);
p_value=2*(1-tcdf(abs(t_static),df));
LL = -fval;
res = y-X*MLE(5:end)';
m = -(res+MLE(1)*MLE(3)*MLE(4)^2);
z = tnor(m',MLE(4)^2,200)';
E1 = (1-exp(-MLE(3)*z)).^(MLE(2)-1);
Eff_mean = mean((z.*E1./E1),2);
Efficiency = exp(-Eff_mean);
MLE = MLE';
end