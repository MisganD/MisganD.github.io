function grad = gradient_weighted(MLE)
g11 = -(1/(MLE(1)^2));
g22 = MLE(1);
grad = [g11 0 0 0 0 0 0 0;
    0 g22 0 0 0 0 0 0;
    0 0 1 0 0 0 0 0;
    0 0 0 1 0 0 0 0;
    0 0 0 0 1 0 0 0;
    0 0 0 0 0 1 0 0;
    0 0 0 0 0 0 1 0;
    0 0 0 0 0 0 0 1];
end