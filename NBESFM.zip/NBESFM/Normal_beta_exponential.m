function [slik] = Normal_beta_exponential(par,y,X,simu)
al = par(1);
be = par(2);
lam = par(3);
s = par(4);
coef = par(5:end); 
E = y-X*coef';
mu = (E-s^2*al*lam);
lik = -E*lam*al+.5*s^2*al^2*lam^2+log(lam)-log(beta(al,be))+log(normcdf(mu/s))+log(mean((1-exp(-lam*tnor(mu',s^2,simu))).^(be-1)))'; 
slik = -sum(lik);
end